const dummyUsers = [
    {
      id: 1,
      username: "user1",
      password: "password1",
      role: "parent"
    },
    {
      id: 2,
      username: "user2",
      password: "password2",
      role: "admin"
    },
    {
      id: 3,
      username: "user3",
      password: "password3",
      role: "instructor"
    },
  ];
  
  export default dummyUsers;
  